# Lab 5 Reflection: Static Code Analysis

## 1. Which issues were the easiest to fix, and which were the hardest? Why?

The easiest issues to fix were style-related problems, unused imports, and the mutable default argument. These changes were relatively straightforward because their solutions involved small, localized edits.

The harder issues were the unsafe use of `eval()`, weak PIN hashing, predictable PIN generation, and hardcoded secrets. These required understanding the security implications of the original implementation and choosing safer alternatives without breaking the program's existing behavior.

## 2. Did the static analysis tools report any false positives? If so, describe one example.

**Complete this answer using the actual reports.**

If no false positives were identified, write:

"After reviewing the findings, I did not identify any definite false positives. The reported issues were either valid problems or warnings that required further investigation."

If a false positive was identified, name the tool, quote or summarize the actual warning, and explain why the code context makes it a false positive. Do not label a genuine security or correctness issue as a false positive merely because the program runs.

## 3. How would you integrate static analysis tools into your actual software development workflow?

I would integrate static analysis into my development workflow by running Pylint, Flake8, and Bandit during development and before committing changes. Pylint would help identify maintainability and code-quality issues, Flake8 would check style and common errors, and Bandit would highlight potentially unsafe coding practices.

For larger projects, I would automate these checks using a continuous integration workflow so that every pull request is analyzed before it is merged. I would review the findings, fix genuine issues, and document justified exceptions.

## 4. What tangible improvements did you observe in the code quality, readability, or potential robustness after applying the fixes?

The changes improved the code's readability, input validation, and error handling. Replacing `eval()` reduced the risk associated with evaluating arbitrary expressions, and secure random-number generation improved temporary PIN generation. Removing the hardcoded secret and improving PIN hashing addressed security weaknesses. Correcting the mutable default argument made account creation more predictable, while clearer validation reduced the chance of invalid transactions.

I also reran the static analysis tools and basic functional tests to evaluate whether the changes improved the code while preserving its intended functionality.
