# Static Analysis Issue Log

## Initial Analysis

The original bank account system was analyzed using Pylint, Bandit, and Flake8. The following issues were identified for investigation and correction.

| Issue | Type | Line(s) | Description | Fix Approach |
|---|---|---|---|---|
| Unsafe expression evaluation | Security | Update from source | `eval()` evaluates a string as Python code, which can execute unintended operations. | Replace expression evaluation with a safe, explicitly defined bonus calculation. |
| Hardcoded secret token | Security | Update from source | A sensitive-looking token is embedded in the source code and printed. | Remove the hardcoded token and avoid printing secrets. |
| Weak PIN hashing | Security | Update from source | MD5 is unsuitable for password/PIN storage. | Use a password-hashing approach designed for credentials, with appropriate salts and work factors. |
| Predictable temporary PIN | Security | Update from source | The standard `random` module is not designed for security-sensitive PIN generation. | Use `secrets` to generate the PIN. |
| Silent exception handling | Robustness | Update from source | A broad exception handler hides errors during deposits. | Validate the account and amount, handle expected errors explicitly, and return a clear result. |
| Mutable default argument | Code quality / correctness | Update from source | A list used as a default argument can be shared across calls. | Use `None` as the default and initialize a new list inside the function. |
| Unused service fee | Correctness | Update from source | A fee is declared in the withdrawal function but is not used. | Implement the intended fee rule or remove the unused variable if no fee is required. |
| File and shell handling | Robustness / security | Update from source | The backup function manually opens a file and invokes a shell command. | Use a context manager for the file and replace shell execution with safe Python output. |

## Fix Verification

After applying the fixes, rerun Pylint, Bandit, and Flake8. Record which findings were resolved, which remain, and any findings determined to be false positives.
