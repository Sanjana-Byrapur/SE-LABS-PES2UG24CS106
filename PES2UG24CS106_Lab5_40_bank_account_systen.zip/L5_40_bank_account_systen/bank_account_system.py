"""Bank account system with secure PIN hashing and transaction management."""
import hashlib
import hmac
import json
import secrets
from pathlib import Path

account_data = {}
SERVICE_FEE = 0.0
PBKDF2_ITERATIONS = 600_000


def get_hash(pin, salt=None):
    """Return a random salt and a PBKDF2-HMAC-SHA256 PIN hash."""
    pin = str(pin)

    if salt is None:
        salt = secrets.token_bytes(16)

    hashed_pin = hashlib.pbkdf2_hmac(
        "sha256",
        pin.encode("utf-8"),
        salt,
        PBKDF2_ITERATIONS,
    )
    return salt, hashed_pin


def verify_pin(pin, salt, stored_hash):
    """Verify a PIN against its stored salt and hash."""
    _, calculated_hash = get_hash(pin, salt)
    return hmac.compare_digest(calculated_hash, stored_hash)


def create_account(acc_id, name, initial_deposit=0, transactions=None):
    """Create an account with an independent transaction list."""
    if acc_id in account_data:
        return False

    if (
        not isinstance(initial_deposit, (int, float))
        or isinstance(initial_deposit, bool)
        or initial_deposit < 0
    ):
        return False

    if transactions is None:
        transactions = []

    account_data[acc_id] = {
        "name": name,
        "balance": float(initial_deposit),
        "transactions": list(transactions),
    }
    account_data[acc_id]["transactions"].append(
        f"Account created with balance {initial_deposit:.2f}"
    )
    return True


def deposit(acc_id, amount):
    """Deposit a positive amount into an existing account."""
    if acc_id not in account_data:
        return False

    if (
        not isinstance(amount, (int, float))
        or isinstance(amount, bool)
        or amount <= 0
    ):
        return False

    account_data[acc_id]["balance"] += amount
    account_data[acc_id]["transactions"].append(
        f"Deposited {amount:.2f}"
    )
    return True


def withdraw(acc_id, amount):
    """Withdraw money if the account has sufficient funds."""
    if acc_id not in account_data:
        return False

    if (
        not isinstance(amount, (int, float))
        or isinstance(amount, bool)
        or amount <= 0
    ):
        return False

    total = amount + SERVICE_FEE
    if account_data[acc_id]["balance"] < total:
        return False

    account_data[acc_id]["balance"] -= total
    account_data[acc_id]["transactions"].append(
        f"Withdrew {amount:.2f}; fee {SERVICE_FEE:.2f}"
    )
    return True


def compute_bonus(acc_id, rate=0.05):
    """Calculate a bonus using a numeric rate, never eval()."""
    if acc_id not in account_data:
        raise ValueError("Account does not exist")

    if (
        not isinstance(rate, (int, float))
        or isinstance(rate, bool)
        or rate < 0
    ):
        raise ValueError("Bonus rate must be a non-negative number")

    return account_data[acc_id]["balance"] * rate


def generate_temp_pin():
    """Generate a cryptographically secure four-digit PIN."""
    return str(secrets.randbelow(9000) + 1000)


def backup_data(filename="backup.txt"):
    """Write account information to a JSON backup file."""
    backup = {}

    for acc_id, account in account_data.items():
        backup[acc_id] = {
            "name": account["name"],
            "balance": account["balance"],
            "transactions": account["transactions"],
        }

    with Path(filename).open("w", encoding="utf-8") as file:
        json.dump(backup, file, indent=4)

    print(f"Backup complete: {filename}")


def main():
    """Run a small demonstration of the banking functions."""
    account_data.clear()

    create_account("A01", "Sanjana", 1000)
    deposit("A01", 300)
    withdraw("A01", 100)

    print("Bonus:", compute_bonus("A01"))

    salt, pin_hash = get_hash("1234")
    print("PIN Hash:", (salt.hex(), pin_hash.hex()))
    print("PIN verification:", verify_pin("1234", salt, pin_hash))

    print("Temp PIN:", generate_temp_pin())
    backup_data()

    # Never hardcode or print a real administrative secret.


if __name__ == "__main__":
    main()
